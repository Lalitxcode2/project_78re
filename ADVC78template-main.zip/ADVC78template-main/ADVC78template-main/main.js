var images = ["https://i.postimg.cc/MGn9GJXw/family.jpg","https://i.postimg.cc/qqyYvVbq/grandpa.jpg", "https://i.postimg.cc/wjMnFtMX/father.jpg" , "https://i.postimg.cc/5ymDKL83/bro.jpg", "https://i.postimg.cc/JnL6wtrd/sister.jpg", "https://i.postimg.cc/bw5W5zSK/mother.jpg"];
var names = ["Fmaily Book","Ranbir Singh", "Diljeet Singh", "Rocky Singh", "Alia Singh", "Soni Singh"];
var i = 0;
function update()
{
  var array_length = images.length-1;

  var update_Img = images[i];

  var update_Name = names[i];
  document.getElementById("family_member_image").src = update_Img;
  document.getElementById("family_member_name").innerHTML = update_Name;

    i++;
    
    
    if(i > array_length)
      {
          i = 0;
      }
    
    //Debug the code to store list of images in updatedImage. Use images[i]
    var updatedImage = [images];
    document.getElementById("family_member_image").src = updatedImage;
    //Debug the code to store list of names in updatedName. Use names[i]
    var updatedName = [names];
    document.getElementById("family_member_name").innerHTML = updatedName;
 
}
